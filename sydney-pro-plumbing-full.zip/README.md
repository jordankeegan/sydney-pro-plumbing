# Sydney Pro Plumbing Website

This is a simple lead generation website built with Next.js + TailwindCSS.

## 🚀 How to run locally
1. Install dependencies:
   ```bash
   npm install
   ```

2. Run the dev server:
   ```bash
   npm run dev
   ```

3. Visit [http://localhost:3000](http://localhost:3000)

## 📦 Deployment
Deploy easily on [Vercel](https://vercel.com).